const path = require("path"),
	  jwt  = require("jsonwebtoken"),
	  _    = require("lodash"),
	  formidable = require('formidable'),
	  fs = require('fs-extra'),
	  mv = require('mv'),
	  crypto =   require('crypto'),

	  /**/
	  env    = require(path.resolve(`./app/config/env/${process.env.NODE_ENV}`)),
	  error  = require(path.resolve(`./app/config/libs/error`)),
	  Mailer  = require(path.resolve(`./app/config/libs/mailer`)),
	  HostPath  = require(path.resolve(`./app/config/libs/hostPath`)),

	  App  = require(path.resolve("./app/controllers/frontend/AppController")),

	  User = require(path.resolve("./app/models/User")),
	  Notification = require(path.resolve("./app/models/Notification")),
	  Request = require(path.resolve("./app/models/Request"));
	  ObjectId= require("mongoose").Types.ObjectId;

class NotificationController extends App {
	constructor(){
		super();
		/**/
		this.notificationView = this.notificationView.bind(this);
		this.getUsersToAlert = this.getUsersToAlert.bind(this);
		this.sendAlert = this.sendAlert.bind(this);
		this.unreadNotificationCount = this.unreadNotificationCount.bind(this);
	}
	/**this method is used to update & see for all Notification
    * method : GET
    * endpoint: /api/notification-view
    */
    notificationView(req,res){
		let user = req.user,
			_match = {to:user._id,seen:false},
			_toUpdate ={$set:{seen:true}};
		/**/
		let _updateNotification = function(){
				return new Promise((resolve,reject)=>{
					//Notification.find
					Notification.update(_match,_toUpdate,{multi:true},(err,update)=>{
						if(err){
							reject(err);
						}else{
							resolve("success");
						}
					});
				})
		    },
			_getNotification = function(result){
				_match = {to:user._id,status:true} 
				return new Promise((resolve,reject)=>{
					Notification.find(_match,function(err,noti){
						if(err) reject(err);
						else resolve(noti);	
					}).limit(10)
				});
			}
			_updateNotification().then((result)=>{
	  	    	return _getNotification(result)
	  	    }).then((result)=>{
	  	        res.json(this.response({ data: result, message: "Success" }));
	  	    }).catch((err)=>{
		  	 	res.json(this.response({ err: err, message: error.oops() }));
		    })
    }
	/*notificationView(req,res){
		let user = req.user,
			_match = {to:user._id,seen:false},
			_toUpdate ={$set:{seen:true}};
		Notification.update(_match,_toUpdate,{multi:true},(err,update)=>{
			if(err){
				res.json(this.response({ err: err, message: error.oops() }));
			}else{
				res.json(this.response({ data: update, message: "All notifications are viewed" }));
			}
		});
    }*/
    /**this method is used to update see for all Notification
    * method : GET
    * endpoint: /api/get-users-to-alert
    */
	getUsersToAlert(req,res){
		
		let user    = req.user,
			obj     = req.query,
			limit   = parseInt(process.env.LIMIT),
	        offset  = (obj.page)?parseInt((obj.page - 1) * limit):0,
			query = new Object(),
			/*this method used to get request*/
			_get_user_friend = function(){
	  	    	return new Promise((resolve, reject) => {
	  	    		let match = {_id:ObjectId(user._id)},
	  	    			project = {friends:1,trackies:1};
	  	    			
	  	    		let query = [
	  	    					{
	  	    						$facet:{
	  	    							friendUser:[
	  	    								{
						  	    				$match:match
							  	    		},
							  	    		{
							  	    			$project:project
							  	    		},
							  	    		{ $unwind : "$friends" },
							  	    		{
							  	    			$project:{friendId:"$friends.user_id"}
							  	    		},
							  	    		{
							  	    			$group : {
												    _id: "$_id",
												    friendsArray: { $addToSet:'$friendId'}
											    }
											}
	  	    							],
	  	    							trackUser:[
	  	    								{
						  	    				$match:match
							  	    		},
							  	    		{
							  	    			$project:project
							  	    		},
							  	    		{ $unwind : "$trackies" },
							  	    		{
							  	    			$project:{trackId:"$trackies.user_id"}
							  	    		},
							  	    		{
							  	    			$group : {
												    _id: "$_id",
												    trackArray: { $addToSet:'$trackId'}
											    }
											}
	  	    							]	
	  	    						}
	  	    					}
			  	    		];
		            User.aggregate(query,(err, userList)=>{
		            	
		            	let friendIds = (userList[0].friendUser.length>0)?userList[0].friendUser[0].friendsArray:[],
		            		trackIds  = (userList[0].trackUser.length>0)?userList[0].trackUser[0].trackArray:[];
		            	
		            	
		            		var other = _.concat(friendIds, trackIds);
		            		
		            		/*this method is to remove duplicate element from array*/
							function removeDuplicates(arr){
							    let unique_array = [],real_array = [];
							    for(let i = 0;i < arr.length; i++){
							        if(unique_array.indexOf(arr[i].toString()) === -1){
							            unique_array.push(arr[i].toString())
							            real_array.push(arr[i])
							        }
							    }
							    return real_array
							}							
							//let allUser = _.shuffle(removeDuplicates(other));
							let allUser = removeDuplicates(other);
		            		
							if(err) reject(err);
							else if (allUser.length>0)resolve(allUser);
		            		else reject('User not found.')
		            })
				}); 
	  	    },
	  	    /*this method used to get user informations for listing*/
	  	    _get_friends_info = function(result){	  	    	
	  	    	return new Promise((resolve, reject) => {
	  	    		let user_ids = result,
	  	    		    match   = {$and:[{_id: { $in: user_ids }}]};
	  	    		if(obj.q) match.$and.push({"name":{ $regex : obj.q, $options : "i" }});    
		  	    	let	query = [
			  	    		{
			  	    			$facet:{
			  	    				count:[
				  	    				{$match:match},
				  	    				{
					  	  			   	   $project:{username:1,name:1,count:"count"}
					  	  			    },
					  	  			    {
							              $group: {
							                _id: '$count',
							                total: { $sum: 1 }
							              }
							            }
			  	    				],
			  	    				userInfo:[
				  	    				{$match:match},
				  	    				{
					  	  			   	   $project:{name:1,profilePicture:1,mobile:1,fullno:1,location:{$ifNull:["$location",""]},created_at:1}
					  	  			    },
					  	  			    { $skip: offset },
					              	    { $limit: limit },
					              	    { $sort : { created_at : -1 } }
			  	    				]
			  	    			}
			  	    		}
	  	    			];
		  	    	User.aggregate(query,(err,users)=>{
		  	    		if(err) reject(err);
			            else if(users.length>0) resolve(users);
			            else reject('Users not found');
		  	    	})
		  	    });
	  	    	
	  	    };
	  	    _get_user_friend().then((result)=>{
	  	    	return _get_friends_info(result)
	  	    }).then((result)=>{
	  	    	res.json(this.response({ data: result, message: "Users found." }));
	  	    }).catch((err)=>{
		  	 	res.json(this.response({ err: err, message: error.oops() }));
		    })
    }
    /**this method is used to send alert to selected users
    * method : POST
    * endpoint: /api/send-alert
    */
	sendAlert(req,res){
		let user = req.user,
			obj = req.body;
		let users_obj = _.map(obj.userIds,function(userId){
			return {
		    	    title: 'Alert Request',
					content: `${obj.message}`, 
					to:  ObjectId(userId),
					from:  user._id,
					types: `Normal`,
					meta : { to: userId, from:user._id}
    	    	 };
		});
		Notification.insertMany(users_obj, (err, noti)=> {
			if(err) res.json(this.response({ err: err, message: error.oops() }));
			else res.json(this.response({ data: noti, message: "Alert has sent to users." })); 
		});	
	}
	/**this method is used to get unread notification count
    * method : POST
    * endpoint: /api/send-alert
    */
	unreadNotificationCount(req,res){
		let user = req.user,
			match = {to:user._id,seen:false};
		Notification.count(match,(err,count)=>{
			if(err) res.json(this.response({ err: err, message: error.oops() }));
			else res.json(this.response({ data: count, message: "Success." })); 
		});
	}
}
module.exports = NotificationController
