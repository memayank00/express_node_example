const path = require("path"),
	  jwt  = require("jsonwebtoken"),
	  _    = require("lodash"),
	  formidable = require('formidable'),
	  fs = require('fs-extra'),
	  mv = require('mv'),
	  crypto =   require('crypto'),

	  /**/
	  env    = require(path.resolve(`./app/config/env/${process.env.NODE_ENV}`)),
	  error  = require(path.resolve(`./app/config/libs/error`)),
	  Mailer  = require(path.resolve(`./app/config/libs/mailer`)),
	  HostPath  = require(path.resolve(`./app/config/libs/hostPath`)),

	  App  = require(path.resolve("./app/controllers/frontend/AppController")),

	  User = require(path.resolve("./app/models/User")),
	  Notification = require(path.resolve("./app/models/Notification")),
	  Request = require(path.resolve("./app/models/Request"));
	  ObjectId= require("mongoose").Types.ObjectId;

class MapController extends App {
	constructor(){
		super();
		/**/
		this.getAllTrackUser = this.getAllTrackUser.bind(this);
		this.sendTrackRequest = this.sendTrackRequest.bind(this);
		this.recievedSentTrackRequest = this.recievedSentTrackRequest.bind(this);	
		this.acceptDeclineTrackRequest = this.acceptDeclineTrackRequest.bind(this);	
		this.cancleTrackRequest = this.cancleTrackRequest.bind(this);
		this.trackList = this.trackList.bind(this);
	}
	/**this method is used to get all list of users to send track
    * method : GET
    * endpoint: /api/tack-list?page=1&text=
    */
	getAllTrackUser(req,res){
    let user    = req.user,
		obj     = req.query,
	    limit   = parseInt(process.env.LIMIT),
        offset  = parseInt((obj.page - 1) * limit),
	    match   = {$and:[{_id: {'$ne': ObjectId(user._id)}},{ mapAvailability: true}]},
  	    select  = {username:1,name:1,email:1,fullno:1,mobile:1,ccode:1,profilePicture:1,location: {$ifNull: ['$location', ''] }}; 
  	   if(obj.text){
  	   	match = {$and:[
  	   		{$or:[
  	   			{username:new RegExp(`^${obj.text}`, 'i')},
  	   			{name:new RegExp(`^${obj.text}`, 'i')},
  	   			{email:new RegExp(`^${obj.text}`, 'i')},
  	   		]},
  	   	    { _id: {'$ne': ObjectId(user._id)}},
  	   	    { mapAvailability: true}
  	   	]};
  	   }
  	  let query = [
  	  	{
  	  		$facet:{
  	  			count:[
  	  			   {
  	  			   	$match:match
  	  			   },
  	  			   {
  	  			   	  $project:{username:1,name:1,email:1,location:1,fullno:1,mobile:1,ccode:1,count:"count"}
  	  			   },
  	  			   {
		             $group: {
		               _id: '$count',
		               total: { $sum: 1 }
		             }
		           }
  	  			],
  	  			userList:[
  	  			   {
  	  			 	  $match:match
  	  			   },
  	  			   {
  	  			   	  $project:select
  	  			   },
  	  			   { $skip: offset },
              	   { $limit: limit }
  	  			]
  	  		}
  	  	}
  	  ];
  	  User.aggregate(query,(err, userList)=>{
	   if(err) res.json(this.response({ err: err, message: error.oops() }));
	   else{
	   	let total = (userList[0].userList.length>0)?userList[0].count[0].total:0;
	   	if(userList[0].userList.length>0){
	   		return res.json(this.response({ data: { users: userList[0].userList ,total:total}, message: "User found" }));	
	   	}else{
	   		return res.json(this.response({ data: { users: userList[0].userList ,total:total}, message: "User Not found" }));	
	   	}
	   }
	  });	
	}
	/**this method is used to send Track request
    * method : POST
    * endpoint: /api/send-track-request
    */
	sendTrackRequest(req,res){
		let user    = req.user,
			obj     = req.body,
		    match   = {$and:[{to_userId:obj.to_userId,from_userId: user._id,type:'Track'}]},
	  	    select  = {to_userId:1,from_userId:1,type:1,status:1};
	  	    obj['from_userId'] = user._id;
	  	    obj['type'] = 'Track';
	  	    obj['status'] = 'Pending';
	  	let _obj_to_save = new Request(obj), 
	  	    _check_for_request = function(){
	  	    	return new Promise((resolve, reject) => {
		            Request.findOne(match,select,(err,request)=>{
		            	if(err) reject(err);
		            	else if(request && request.status === 'Pending') reject('Your Track request is Pending.');
		            	else if(request && request.status === 'Rejected') resolve('Rejected');
		            	else if(request && request.status === 'Accepted') reject('This user already in your track list.');
		            	else if(request && request.status === 'Deleted') resolve('Deleted');
		            	else resolve('Request to send.')

		            })
				}); 
	  	    },
	  	    _save_for_request = function(result){
	  	    	let _status_array = ['Rejected','Deleted'];
	  	    	return new Promise((resolve, reject) => {
		  	    	if(_status_array.includes(result) ){
		  	    		/*remove previous request from request model*/
		  	    		Request.remove(match,(err,result)=>{});
		  	    	}
		  	    	/*save track request obj in request collection*/
		  	    	_obj_to_save.save((err,saved_obj)=>{
		  	    		resolve(saved_obj);
				  	})
		  	    });
	  	    },
	  	    _save_for_notification = function(result){
	  	    	let _notification = new Notification({
	  	    	    	title: 'Track Request',
						content: `${user.name} sent you track request`, 
						to:  obj.to_userId,
						from:  user._id,
						types: `Track`,
						meta : { to: obj.to_userId, from:user._id}
	  	    	    });
	  	    	return new Promise((resolve, reject) => {
		  	    	/*save notification in */
		  	    	_notification.save((err,saved_obj)=>{
		  	    		resolve(result);
				  	})
		  	    });
	  	    };
	  	    _check_for_request().then((result)=>{
	  	    	return _save_for_request(result)
	  	    }).then((result)=>{
	  	        return _save_for_notification(result)
	  	    }).then((result)=>{
	  	        res.json(this.response({ data: result._id, message: "Track request has sent." }));
	  	    }).catch((err)=>{
	  	    	console.log(err)
		  	 	res.json(this.response({ err: err, message: error.oops() }));
		    })  
	}
	/**this method is used to see recived & sent track request
    * method : GET
    * endpoint: /api/recieved-sent-track-request
    */
	recievedSentTrackRequest(req,res){
		let user    = req.user,
			obj     = req.query,
			query = new Object(),
			/*this method used to get request*/
			_check_for_request = function(){
	  	    	return new Promise((resolve, reject) => {
	  	    		let match =(obj.type==='sent')? {from_userId:ObjectId(user._id)}:{to_userId:ObjectId(user._id)},
	  	    			project = (obj.type==='sent')? {to_userId:1}:{from_userId:1},
	  	    			addToSet = (obj.type==='sent')? `$to_userId`:`$from_userId`;
	  	    			project['group_array']=null;
	  	    			match['status']='Pending';
	  	    			match['type']='Track';
	  	    		query = [
			  	    			{
			  	    				$match:match
				  	    		},
				  	    		{
				  	    			$project:project
				  	    		},
				  	    		{
				  	    			$group : {
									    _id: "$group_array",
									    itemsSold: { $addToSet:addToSet}
								    }
								}
			  	    		]
		            Request.aggregate(query,(err, userList)=>{
		            	if(err) reject(err);
		            	else if (userList.length>0)resolve(userList);
		            	else reject('request not found.')
		            })
				}); 
	  	    },
	  	    /*this method used to get user informations for listing*/
	  	     _get_users_info = function(result){	
	  	    	return new Promise((resolve, reject) => {
	  	    		let user_ids = result[0].itemsSold;
	  	    		let query  = [
	  	    					{
			  	    				$match:{ _id: { $in: user_ids }}
				  	    		},
				  	    		{
				  	    			$project:{
				  	    				name:1,profilePicture:1,location:{$ifNull:["$location",""]}
				  	    			}
				  	    		}
	  	    		]
		  	    	User.aggregate(query,(err,users)=>{
		  	    		if(err) reject(err);
			            else if(users.length>0) resolve(users);
			            else reject('Users not found');
		  	    	})
		  	    });
	  	    	
	  	    };
	  	    _check_for_request().then((result)=>{
	  	    	return _get_users_info(result)
	  	    }).then((result)=>{
	  	    	res.json(this.response({ data: result, message: "Request found." }));
	  	    }).catch((err)=>{
		  	 	res.json(this.response({ err: err, message: error.oops() }));
		    })
	}
	/**this method is used to see recived & sent track request
    * method : POST
    * endpoint: /api/accept-decline-track-request
    */

	acceptDeclineTrackRequest(req,res){
		let user    = req.user,
			obj     = req.body,
			query = new Object(), 
			/*this method used update status of request*/
			_update_request_status = function(){
				let match = {to_userId:user._id,from_userId:obj._id,type:'Track'},
					toUpdate = (obj.type ==='Accepted')?{$set:{status : "Accepted"}}:{$set:{status : "Rejected"}};
	  	    	return new Promise((resolve, reject) => {
	  	    		Request.findOne(match,(err,result)=>{
	  	    			if(err) reject(err);
	  	    			if(result){
	  	    				Request.update(match,toUpdate,(err,result)=>{
			  	    			if(err) reject(err);
			  	    			else resolve(result);
			  	    		})
	  	    			}else{
	  	    				reject('It seems this request is invalid.')
	  	    			}
	  	    		});	
				}); 
	  	    },
	  	    /*this method used to update user Track listing*/
	  	    _push_friend_User = function(result){
	  	    	return new Promise((resolve, reject) => {
	  	    		if(obj.type !=='Accepted'){
	  	    			resolve(`Track Request ${obj.type}.`);
	  	    		}else{
	  	    			User.update(
					      //{ _id: user._id},
					      { _id: obj._id},
					      { $pull: {trackies:{user_id:user._id} }},
					      (err,update)=>{

					    });
					    //User.findOne({_id : obj._id},(err,userObj)=>{
					     User.findOne({_id : user._id},(err,userObj)=>{
					    	if(err) reject(err);
					    	else{
					    		let trackie = {
					    			user_id : userObj._id,
							        name : userObj.name,
							        location : userObj.location,
							        profilePicture: (userObj.profilePicture)? userObj.profilePicture:null
					    		};
					    		//User.update({ _id: user._id},
					    		User.update({ _id: obj._id},
					  	    		{ $push: { trackies: trackie } },
					  	    		(err,result)=>{
					  	    		if(err) reject(err);
						            else resolve(`Track Request ${obj.type}.`);
					  	    	});
					    	}
					    });
	  	    		}

		  	    });	
	  	    },
	  	    /*this method used to update notification & save new notification*/
	  	    _update_notification = function(result){
	  	    	return new Promise((resolve, reject) => {
	  	    		let _match = {to:user._id, from:obj._id,types : "Track"},
	  	    			_to_update = {$set:{status:false}};
	  	    			/*update previous notification*/
	  	    		Notification.update(_match,_to_update,(err,update)=>{
	  	    			if(err){
	  	    				reject(err);
	  	    			}else{
	  	    				/*create new notification*/
		  	    			let _notification = new Notification({
				  	    	    	title: 'Track Request Accepted',
									content: `Your track request accepted by ${user.name}`, 
									to:  obj._id,
									from:  user._id,
									types: `Normal`,
									meta : { to: obj._id, from:user._id}
				  	    	    });
			  	    		
					  	    	/*save notification in */
					  	    	_notification.save((err,saved_obj)=>{
					  	    		resolve(result);
							  	})
		  	   			}
				    });	
		  	    });	
	  	    };
	  	    _update_request_status().then((result)=>{
	  	    	return _push_friend_User(result)
	  	    }).then((result)=>{
	  	    	return _update_notification(result)
	  	    }).then((result)=>{
	  	    	res.json(this.response({ data: result, message: "Request found." }));
	  	    }).catch((err)=>{
		  	 	res.json(this.response({ err: err, message: error.oops() }));
		    }) 

	}
   /**this method is used to cancle or remove track request
    * method : POST
    * endpoint: /api/cancle-track-request
    */
	cancleTrackRequest(req,res){
		let user    = req.user,
			obj     = req.body,
			query = new Object(), 
			/*this method used update status of request*/
			_update_request_status = function(){
				let match = {from_userId:user._id,to_userId:obj.to_userId,type:'Track'};
	  	    	return new Promise((resolve, reject) => {
	  	    		Request.remove(match,(err,result)=>{
	  	    			if(err) reject(err);
	  	    			else resolve(result);
	  	    		});	
				}); 
	  	    },
	  	    /*this method used to update user track listing
	  	     *this function will work in rare case.
	  	    */
	  	    _pull_friend_User = function(result){
	  	    	return new Promise((resolve, reject) => {
	  	    		User.update(
				      { _id: user._id},
				      { $pull: {trackies:{user_id:obj.to_userId} }},
				      (err,update)=>{
				      	if(err) reject(err);
	  	    			else resolve(result);
				    });
		  	    });	
	  	    };
	  	    _update_request_status().then((result)=>{
	  	    	return _pull_friend_User(result)
	  	    }).then((result)=>{
	  	    	res.json(this.response({ data: result, message: "Request has canceled." }));
	  	    }).catch((err)=>{
		  	 	res.json(this.response({ err: err, message: error.oops() }));
		    })
	}
	/**this method is used to see track list
    * method : GET
    * endpoint: /api/track-list
    */
	trackList(req,res){
		let user    = req.user,
			obj     = req.query,
			query = new Object(),
			/*this method used to get request*/
			_get_user_trackies = function(){
	  	    	return new Promise((resolve, reject) => {
	  	    		let match = {_id:ObjectId(user._id)},
	  	    			project = {trackies:1};
	  	    			
	  	    		query = [
			  	    			{
			  	    				$match:match
				  	    		},
				  	    		{
				  	    			$project:project
				  	    		},
				  	    		{ $unwind : "$trackies" },
				  	    		{
				  	    			$project:{trackieId:"$trackies.user_id"}
				  	    		},
				  	    		{
				  	    			$group : {
									    _id: "$_id",
									    trackiesArray: { $addToSet:'$trackieId'}
								    }
								}
			  	    		]
		            User.aggregate(query,(err, userList)=>{

		            	if(err) reject(err);
		            	else if (userList.length>0 && userList[0].trackiesArray.length>0)resolve(userList);
		            	else reject('Friend not found.')
		            })
				}); 
	  	    },
	  	    /*this method used to get user informations for listing*/
	  	    _get_trackies_info = function(result){
	  	    	return new Promise((resolve, reject) => {
	  	    		let user_ids = result[0].trackiesArray;
	  	    			query = [
	  	    				{$match:{_id: { $in: user_ids }}},
	  	    				{$project:{name:1,profilePicture:1,mobile:1,fullno:1,location:{$ifNull:["$location",""]},cordinate:1}}
	  	    			]
		  	    	User.aggregate(query,(err,users)=>{
		  	    		if(err) reject(err);
			            else if(users.length>0) resolve(users);
			            else reject('Users not found');
		  	    	})
		  	    });
	  	    	
	  	    };
	  	    _get_user_trackies().then((result)=>{
	  	    	return _get_trackies_info(result)
	  	    }).then((result)=>{
	  	    	res.json(this.response({ data: result, message: "Trackies found." }));
	  	    }).catch((err)=>{
		  	 	res.json(this.response({ err: err, message: error.oops() }));
		    })
	}
}
module.exports = MapController
