const path = require("path"),
	  jwt  = require("jsonwebtoken"),
	  _    = require("lodash"),
	  formidable = require('formidable'),
	  fs = require('fs-extra'),
	  mv = require('mv'),
	  crypto =   require('crypto'),
	  ASYNC  =   require('async'),

	  /**/
	  env    = require(path.resolve(`./app/config/env/${process.env.NODE_ENV}`)),
	  error  = require(path.resolve(`./app/config/libs/error`)),
	  Mailer  = require(path.resolve(`./app/config/libs/mailer`)),
	  HostPath  = require(path.resolve(`./app/config/libs/hostPath`)),
	  DECODE  = require(path.resolve(`./app/config/libs/verify_jwt`)),

	  App  = require(path.resolve("./app/controllers/frontend/AppController")),

	  User = require(path.resolve("./app/models/User")),
	  Request = require(path.resolve("./app/models/Request")),
	  Conversation = require(path.resolve("./app/models/Conversation")),
	  Notification = require(path.resolve("./app/models/Notification")),
	  ObjectId= require("mongoose").Types.ObjectId;
//{location: {$ifNull: ['$location', '']} }
class FriendController extends App {
	constructor(){
		super();
		/**/
		this.getAllUser = this.getAllUser.bind(this);
		this.sendFriendRequest = this.sendFriendRequest.bind(this);
		this.recievedSentFriendRequest = this.recievedSentFriendRequest.bind(this);	
		this.acceptDeclineFriendRequest = this.acceptDeclineFriendRequest.bind(this);	
		this.cancleFriendRequest = this.cancleFriendRequest.bind(this);
		this.friendList = this.friendList.bind(this);
	}
	/**this method is used to get all list of users
    * method : GET
    * endpoint: /api/get-all-user
    */
	getAllUser(req,res){
    let user    = req.user,
		obj     = req.query,
	    limit   = parseInt(process.env.LIMIT),
        offset  = parseInt((obj.page - 1) * limit),
	    match   = {$and:[{_id: {'$ne': ObjectId(user._id)}}]},
  	    select  = {username:1,name:1,email:1,fullno:1,mobile:1,ccode:1,profilePicture:1,location: {$ifNull: ['$location', ''] }}; 
  	   if(obj.text){
  	   	match = {$and:[
  	   		{$or:[
  	   			{username:new RegExp(`^${obj.text}`, 'i')},
  	   			{name:new RegExp(`^${obj.text}`, 'i')},
  	   			{email:new RegExp(`^${obj.text}`, 'i')},
  	   		]},
  	   	    {_id: {'$ne': ObjectId(user._id)}}
  	   	]};
  	   }
  	  let query = [
  	  	{
  	  		$facet:{
  	  			count:[
  	  			   {
  	  			   	$match:match
  	  			   },
  	  			   {
  	  			   	  $project:{username:1,name:1,email:1,location:1,fullno:1,mobile:1,ccode:1,count:"count"}
  	  			   },
  	  			   {
		             $group: {
		               _id: '$count',
		               total: { $sum: 1 }
		             }
		           }
  	  			],
  	  			userList:[
  	  			   {
  	  			 	  $match:match
  	  			   },
  	  			   {
  	  			   	  $project:select
  	  			   },
  	  			   { $skip: offset },
              	   { $limit: limit }
  	  			]
  	  		}
  	  	}
  	  ];
  	  User.aggregate(query,(err, userList)=>{
	   if(err) res.json(this.response({ err: err, message: error.oops() }));
	   else{
	   	let total = (userList[0].userList.length>0)?userList[0].count[0].total:0;
	   	if(userList[0].userList.length>0){
	   		return res.json(this.response({ data: { users: userList[0].userList ,total:total}, message: "User found" }));	
	   	}else{
	   		return res.json(this.response({ data: { users: userList[0].userList ,total:total}, message: "User Not found" }));	
	   	}
	   }
	  });	
	}
	/**this method is used to send friend request
    * method : POST
    * endpoint: /api/send-friend-request
    */
	sendFriendRequest(req,res){
		let user    = req.user,
			obj     = req.body,
		    match   = {$and:[{to_userId:obj.to_userId,from_userId: user._id,type:'Friend'}]},
	  	    select  = {to_userId:1,from_userId:1,type:1,status:1};
	  	    obj['from_userId'] = user._id;
	  	    obj['type'] = 'Friend';
	  	    obj['status'] = 'Pending';
	  	let _obj_to_save = new Request(obj), 
	  	    _check_for_request = function(){
	  	    	return new Promise((resolve, reject) => {
		            Request.findOne(match,select,(err,request)=>{
		            	if(err) reject(err);
		            	else if(request && request.status === 'Pending') reject('Your Friend request is Pending.');
		            	else if(request && request.status === 'Rejected') resolve('Rejected');
		            	else if(request && request.status === 'Accepted') reject('This user already in your friend list.');
		            	else if(request && request.status === 'Deleted') resolve('Deleted');
		            	else resolve('Request to send.')

		            })
				}); 
	  	    },
	  	    _save_for_request = function(result){
	  	    	let _status_array = ['Rejected','Deleted'];
	  	    	return new Promise((resolve, reject) => {
		  	    	if(_status_array.includes(result) ){
		  	    		/*remove previous request from request model*/
		  	    		Request.remove(match,(err,result)=>{});
		  	    	}
		  	    	/*save friend request obj in request collection*/
		  	    	_obj_to_save.save((err,saved_obj)=>{
		  	    		resolve(saved_obj);
				  	})
		  	    });
	  	    },
	  	    _save_for_notification = function(result){
	  	    	let _notification = new Notification({
	  	    	    	title: 'Friend Request',
						content: `${user.name} sent you friend request`, 
						to:  obj.to_userId,
						from:  user._id,
						types: `Friend`,
						meta : { to: obj.to_userId, from:user._id}
	  	    	    });
	  	    	return new Promise((resolve, reject) => {
		  	    	/*save notification in */
		  	    	_notification.save((err,saved_obj)=>{
		  	    		resolve(result);
				  	})
		  	    });
	  	    };
	  	    _check_for_request().then((result)=>{
	  	    	return _save_for_request(result)
	  	    }).then((result)=>{
	  	    	return _save_for_notification(result)
	  	    }).then((result)=>{
	  	        res.json(this.response({ data: result._id, message: "Friend request has sent." }));
	  	    }).catch((err)=>{
		  	 	res.json(this.response({ err: err, message: error.oops() }));
		    })  
	}
	/**this method is used to see recived & sent friend request
    * method : GET
    * endpoint: /api/recieved-sent-friend-request
    */
	recievedSentFriendRequest(req,res){
		let user    = req.user,
			obj     = req.query,
			query = new Object(),
			/*this method used to get request*/
			_check_for_request = function(){
	  	    	return new Promise((resolve, reject) => {
	  	    		let match =(obj.type==='sent')? {from_userId:ObjectId(user._id)}:{to_userId:ObjectId(user._id)},
	  	    			project = (obj.type==='sent')? {to_userId:1}:{from_userId:1},
	  	    			addToSet = (obj.type==='sent')? `$to_userId`:`$from_userId`;
	  	    			project['group_array']=null;
	  	    			match['status']='Pending';
	  	    			match['type']='Friend';
	  	    		query = [
			  	    			{
			  	    				$match:match
				  	    		},
				  	    		{
				  	    			$project:project
				  	    		},
				  	    		{
				  	    			$group : {
									    _id: "$group_array",
									    itemsSold: { $addToSet:addToSet}
								    }
								}
			  	    		]
		            Request.aggregate(query,(err, userList)=>{
		            	if(err) reject(err);
		            	else if (userList.length>0)resolve(userList);
		            	else reject('request not found.')
		            })
				}); 
	  	    },
	  	    /*this method used to get user informations for listing*/
	  	    _get_users_info = function(result){	
	  	    	return new Promise((resolve, reject) => {
	  	    		let user_ids = result[0].itemsSold;
	  	    		let query  = [
	  	    					{
			  	    				$match:{ _id: { $in: user_ids }}
				  	    		},
				  	    		{
				  	    			$project:{
				  	    				name:1,profilePicture:1,location:{$ifNull:["$location",""]}
				  	    			}
				  	    		}
	  	    		]
		  	    	User.aggregate(query,(err,users)=>{
		  	    		if(err) reject(err);
			            else if(users.length>0) resolve(users);
			            else reject('Users not found');
		  	    	})
		  	    });
	  	    	
	  	    };
	  	    _check_for_request().then((result)=>{
	  	    	return _get_users_info(result)
	  	    }).then((result)=>{
	  	    	res.json(this.response({ data: result, message: "Request found." }));
	  	    }).catch((err)=>{
		  	 	res.json(this.response({ err: err, message: error.oops() }));
		    })
	}
	/**this method is used to see recived & sent friend request
    * method : POST
    * endpoint: /api/accept-decline-friend-request
    */
	acceptDeclineFriendRequest(req,res){
		let user    = req.user,that = this,
			obj     = req.body,
			query = new Object(),
			user1 =  new Object(),
			user2 =  new Object(),
			/*this method used update status of request*/
			_update_request_status = function(){
				let match = {to_userId:user._id,from_userId:obj._id,type:'Friend'},
					toUpdate = (obj.type ==='Accepted')?{$set:{status : "Accepted"}}:{$set:{status : "Rejected"}};
	  	    	return new Promise((resolve, reject) => {
	  	    		/*Request.update(match,toUpdate,(err,result)=>{
	  	    			if(err) reject(err);
	  	    			else resolve(result);
	  	    		})*/

	  	    		Request.findOne(match,(err,result)=>{
	  	    			if(err) reject(err);
	  	    			if(result){
	  	    				Request.update(match,toUpdate,(err,result)=>{
			  	    			if(err) reject(err);
			  	    			else resolve(result);
			  	    		})
	  	    			}else{
	  	    				reject('It seems this request is invalid.')
	  	    			}
	  	    		});		
				}); 
	  	    },
	  	    /*this method used to update user1 friend listing*/
	  	    _push_friend_User1 = function(result){
	  	    	return new Promise((resolve, reject) => {
	  	    		if(obj.type !=='Accepted'){
	  	    			resolve(`Friend Request ${obj.type}.`);
	  	    		}else{
	  	    			User.update(
					      { _id: user._id},
					      { $pull: {friends:{user_id:obj._id} }},
					      (err,update)=>{

					    });
					    User.findOne({_id : obj._id},(err,userObj)=>{
					    	if(err) reject(err);
					    	else{
					    		user1 = userObj;
					    		let friend = {
					    			user_id : userObj._id,
							        name : userObj.name,
							        location : userObj.location,
							        profilePicture: (userObj.profilePicture)? userObj.profilePicture:null
					    		};
					    		User.update({ _id: user._id},
					  	    		{ $push: { friends: friend } },
					  	    		(err,result)=>{
					  	    		if(err) reject(err);
						            else resolve(`Friend Request ${obj.type}.`);
					  	    	});
					    	}
					    });
	  	    		}

		  	    });	
	  	    },
	  	    /*this method used to update user2 friend listing*/
	  	    _push_friend_User2 = function(result){
	  	    	return new Promise((resolve, reject) => {
	  	    		if(obj.type !=='Accepted'){
	  	    			resolve(`Friend Request ${obj.type}.`);
	  	    		}else{
	  	    			User.update(
					      { _id: obj._id},
					      { $pull: {friends:{user_id:user._id} }},
					      (err,update)=>{

					    });
					    User.findOne({_id : user._id},(err,userObj)=>{
					    	if(err) reject(err);
					    	else{
					    		user2 = userObj;
					    		let friend = {
					    			user_id : userObj._id,
							        name : userObj.name,
							        location : userObj.location,
							        profilePicture: (userObj.profilePicture)? userObj.profilePicture:null
					    		};
					    		User.update({ _id: obj._id},
					  	    		{ $push: { friends: friend } },
					  	    		(err,result)=>{
					  	    		if(err) reject(err);
						            else resolve(`Friend Request ${obj.type}.`);
					  	    	});
					    	}
					    });
	  	    		}

		  	    });	
	  	    },
	  	     /*this method used to update notification & save new notification*/
	  	    _update_notification = function(result){
	  	    	return new Promise((resolve, reject) => {
	  	    		let _match = {to:user._id, from:obj._id,types : "Friend"},
	  	    			_to_update = {$set:{status:false}};
	  	    			/*update previous notification*/
	  	    		Notification.update(_match,_to_update,(err,update)=>{
	  	    			if(err){
	  	    				reject(err);
	  	    			}else{
	  	    				/*create new notification*/
		  	    			let _notification = new Notification({
				  	    	    	title: 'Friend Request Accepted',
									content: `Your friend request accepted by ${user.name}`, 
									to:  obj._id,
									from:  user._id,
									types: `Normal`,
									meta : { to: obj._id, from:user._id}
				  	    	    });
			  	    		
				  	    	/*save notification in */
				  	    	_notification.save((err,saved_obj)=>{
				  	    		resolve(result);
						  	})
		  	   			}
				    });	
		  	    });	
	  	    },
	  	    /*this method used to create initial conversation*/
	  	    _create_initial_convertation = function(result){
	  	    	return new Promise((resolve, reject) => {
			        const users = [
			            {
			                _id : user1._id,
			                name : user1.name,
			                image : user1.profilePicture
			            },
			            {
			                _id : user2._id,
			                name : user2.name,
			                image : user2.profilePicture
			            }
			        ];
			        /**
			         * params : chatUsers, currentUsers, status currentUsers:[]
			         */
			        DECODE.required(req, res, (user)=> {
			            let query = {
			                 "currentUsers": { $size : 2, $all: that.getUserIds(users) }  
			            };
			            Conversation.find(query,(err,conver)=>{
			                if(err){
			                    res.status(412).json({type:"error",message:ERROR.oops(),errors:ERROR.pull(err)})
			                }else{
			                   if(conver.length>0) {
			                    /*if convertation found*/
			                    Conversation.update({_id:conver[0]._id},{$set:{status:"Connected"}},
			                    (err,result)=>{
			                        if(err) reject(err);
			                        if(result) resolve(`Friend Request ${obj.type}.`);
			                    });
			                   }else{
			                    /*if convertation not found*/
			                    ASYNC.waterfall([
			                        (_callback) => {
			                            Conversation.find({
			                                currentUsers : {
			                                    $all : that.getUserIds(users)
			                                }
			                            }, (err, userGroup) => {
			                                if(userGroup && userGroup.length){
			                                    _callback("This room is already exists.");
			                                }else{
			                                    _callback(null);
			                                }
			                            });
			                        },
			                        (_callback) => {
			                            let newConversation = {
			                                chatUsers : users,
			                                currentUsers : that.getUserIds(users),
			                                status : "Connected"
			                            };

			                            /*create a connection between users*/
			                            Conversation(newConversation).save()
			                            .then(conversationId => _callback(null,conversationId))
			                            .catch(error => _callback(error));
			                        }
			                    ], (err, result) => {
			                        if(err) reject(err);
			                        if(result){
			                            resolve(`Friend Request ${obj.type}.`)
			                        }
			                    });
			                   }
			                }
			            });
			        });

		  	    });	
	  	    };_update_notification
	  	    _update_request_status().then((result)=>{
	  	    	return _push_friend_User1(result)
	  	    }).then((result)=>{
	  	    	return _push_friend_User2(result)
	  	    }).then((result)=>{
	  	    	return _update_notification(result)
	  	    }).then((result)=>{
	  	    	return _create_initial_convertation(result)
	  	    }).then((result)=>{
	  	    	res.json(this.response({ data: result, message: "Request found." }));
	  	    }).catch((err)=>{
		  	 	res.json(this.response({ err: err, message: error.oops() }));
		    }) 

	}
   /**this method is used to cancle friend request
    * method : POST
    * endpoint: /api/cancle-friend-request
    */
	cancleFriendRequest(req,res){
		let user    = req.user,
			obj     = req.body,
			query = new Object(), 
			/*this method used update status of request*/
			_update_request_status = function(){
				let match = {from_userId:user._id,to_userId:obj.to_userId,type:'Friend'};
	  	    	return new Promise((resolve, reject) => {
	  	    		Request.remove(match,(err,result)=>{
	  	    			if(err) reject(err);
	  	    			else resolve(result);
	  	    		});	
				}); 
	  	    },
	  	    /*this method used to update user friend listing
	  	     *this function will work in rare case.
	  	    */
	  	    _pull_friend_User = function(result){
	  	    	return new Promise((resolve, reject) => {
	  	    		User.update(
				      { _id: user._id},
				      { $pull: {friends:{user_id:obj.to_userId} }},
				      (err,update)=>{
				      	if(err) reject(err);
	  	    			else resolve(result);
				    });
		  	    });	
	  	    };
	  	    _update_request_status().then((result)=>{
	  	    	return _pull_friend_User(result)
	  	    }).then((result)=>{
	  	    	res.json(this.response({ data: result, message: "Request has canceled." }));
	  	    }).catch((err)=>{
		  	 	res.json(this.response({ err: err, message: error.oops() }));
		    })
	}
	/**this method is used to see friend list
    * method : GET
    * endpoint: /api/friend-list
    */
	friendList(req,res){
		let user    = req.user,
			obj     = req.query,
			query = new Object(),
			/*this method used to get request*/
			_get_user_friend = function(){
	  	    	return new Promise((resolve, reject) => {
	  	    		let match = {_id:ObjectId(user._id)},
	  	    			project = {friends:1};
	  	    			
	  	    		query = [
			  	    			{
			  	    				$match:match
				  	    		},
				  	    		{
				  	    			$project:project
				  	    		},
				  	    		{ $unwind : "$friends" },
				  	    		{
				  	    			$project:{friendId:"$friends.user_id"}
				  	    		},
				  	    		{
				  	    			$group : {
									    _id: "$_id",
									    friendsArray: { $addToSet:'$friendId'}
								    }
								}
			  	    		]
		            User.aggregate(query,(err, userList)=>{

		            	if(err) reject(err);
		            	else if (userList.length>0 && userList[0].friendsArray.length>0)resolve(userList);
		            	else reject('Friend not found.')
		            })
				}); 
	  	    },
	  	    /*this method used to get user informations for listing*/
	  	    _get_friends_info = function(result){
	  	    	return new Promise((resolve, reject) => {
	  	    		let user_ids = result[0].friendsArray;
		  	    		query = [
	  	    				{$match:{_id: { $in: user_ids }}},
	  	    				{$project:{name:1,profilePicture:1,mobile:1,fullno:1,location:{$ifNull:["$location",""]}}}
	  	    			]
		  	    	User.aggregate(query,(err,users)=>{
		  	    		if(err) reject(err);
			            else if(users.length>0) resolve(users);
			            else reject('Users not found');
		  	    	})
		  	    });
	  	    	
	  	    };
	  	    _get_user_friend().then((result)=>{
	  	    	return _get_friends_info(result)
	  	    }).then((result)=>{
	  	    	res.json(this.response({ data: result, message: "Friends found." }));
	  	    }).catch((err)=>{
		  	 	res.json(this.response({ err: err, message: error.oops() }));
		    })
	}
}
module.exports = FriendController
