'use strict';

const path            = require('path'),
    fs              = require('fs'),
    expressJWT      = require('express-jwt'),
    env             = require(path.resolve(`./app/config/env/${process.env.NODE_ENV}`)),
    api_path        = env.API.site,
    admin_api_path  = env.API.admin;

class AppRouter {
    constructor(app, router){
        this.call = {
            frontend : {}
        };
        this.frontend = {};
        this.backend = {};

        /**/
        this.api_path = api_path;
        this.admin_api_path = admin_api_path;

        /**/
        this.app = app;
        this.router = router;
    }

    loadAppClasses(){
        fs.readdirSync(path.resolve('./app/controllers/frontend')).forEach(file => {
            let name = file.substr(0, file.indexOf('.'));
            /*Store Classes in frontend object*/
            this.frontend[name] = require(path.resolve(`./app/controllers/frontend/${name}`));
            /*Init All Classes & add Object to Array*/
            this.call['frontend'][name] = new this.frontend[name]();
        });
    }

    unlessRoutes(){
        this.router.use(expressJWT({
            secret: env.secret //new Buffer(env.secret).toString('base64'),
        }).unless({
            path: [
                this.api_path+'user-login',
                this.api_path+'user-signup',
                this.api_path+'verify-otp'
            ]
        }));
    }

    loadAppRoutes(){
        /*User routes*/
        this.router.post('/user-login', this.call['frontend']['UserController'].userLogin);
        this.router.post('/user-signup', this.call['frontend']['UserController'].userSignup);
        this.router.post('/verify-otp', this.call['frontend']['UserController'].verifyOTP);
        this.router.post('/add-user-notes', this.call['frontend']['UserController'].addUserNotes);
        this.router.get('/other-user-details', this.call['frontend']['UserController'].otherUserDetails);
        this.router.get('/user-details', this.call['frontend']['UserController'].userDetails);
        this.router.put('/update-user-details', this.call['frontend']['UserController'].updateUserDetails);
        this.router.post('/update-profile-picture', this.call['frontend']['UserController'].updateProfilePicture);
        this.router.post('/change-password', this.call['frontend']['UserController'].changePassword);
        this.router.post('/update-user-location', this.call['frontend']['UserController'].updateUserLocation);
        this.router.post('/toogle-user-availability', this.call['frontend']['UserController'].toogleUserAvailability);
        /*Friend routes*/
        this.router.get('/get-all-user', this.call['frontend']['FriendController'].getAllUser);
        this.router.post('/send-friend-request', this.call['frontend']['FriendController'].sendFriendRequest);
        this.router.get('/recieved-sent-friend-request', this.call['frontend']['FriendController'].recievedSentFriendRequest);
        this.router.post('/accept-decline-friend-request', this.call['frontend']['FriendController'].acceptDeclineFriendRequest);
        this.router.post('/cancle-friend-request', this.call['frontend']['FriendController'].cancleFriendRequest);
        this.router.get('/friend-list', this.call['frontend']['FriendController'].friendList);
        /*Track List routes*/
        this.router.get('/get-all-track-user', this.call['frontend']['MapController'].getAllTrackUser);
        this.router.post('/send-track-request', this.call['frontend']['MapController'].sendTrackRequest);
        this.router.get('/recieved-sent-track-request', this.call['frontend']['MapController'].recievedSentTrackRequest);
        this.router.post('/accept-decline-track-request', this.call['frontend']['MapController'].acceptDeclineTrackRequest);
        this.router.post('/cancle-track-request', this.call['frontend']['MapController'].cancleTrackRequest);
        this.router.get('/track-list', this.call['frontend']['MapController'].trackList);
        /*Messages routes*/
        this.router.get('/get-all-chat-list', this.call['frontend']['MessageController'].getAllChatList);
        this.router.get('/get-conversation-id', this.call['frontend']['MessageController'].getConversationId);
        this.router.post('/send-message', this.call['frontend']['MessageController'].sendMessage);
        this.router.post('/message-trails', this.call['frontend']['MessageController'].messageTrails);
        /*Notification routes*/
        this.router.get('/notification-view', this.call['frontend']['NotificationController'].notificationView);
        this.router.get('/get-users-to-alert', this.call['frontend']['NotificationController'].getUsersToAlert);
        this.router.post('/send-alert', this.call['frontend']['NotificationController'].sendAlert);
        this.router.get('/unread-notification-count', this.call['frontend']['NotificationController'].unreadNotificationCount);
    }

    init(){
        this.loadAppClasses();
        this.unlessRoutes();
        this.loadAppRoutes();

        return this.router;
    }
}

module.exports = AppRouter;