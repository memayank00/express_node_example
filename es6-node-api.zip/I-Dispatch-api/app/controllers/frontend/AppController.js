const path = require("path");

class App {

	constructor(){
		//console.log("from App cont. constructor");
		this.welcome = "Welcome to NodeJS ES6";
	}

	callme(){
		console.log("init app controler");
	}
	/**
     * 
     */
    response(object){
        return {
            type: !object.err ? "success" : "error",
            message: object.message ? object.message : "Data Sent",
            data: object.data ? object.data : [],
            errors: object.err ? object.err : [],
            status: !object.err ? 1 : 0
        };
    }
}

module.exports = App;