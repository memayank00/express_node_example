const path = require("path"),
	  jwt  = require("jsonwebtoken"),
	  _    = require("lodash"),
	  formidable = require('formidable'),
	  fs = require('fs-extra'),
	  mv = require('mv'),

	  /**/
	  env    = require(path.resolve(`./app/config/env/${process.env.NODE_ENV}`)),
	  error  = require(path.resolve(`./app/config/libs/error`)),
	  Mailer  = require(path.resolve(`./app/config/libs/mailer`)),
	  HostPath  = require(path.resolve(`./app/config/libs/hostPath`)),


	  App  = require(path.resolve("./app/controllers/frontend/AppController")),


	  User = require(path.resolve("./app/models/User"));
	  //OTP  = require(path.resolve("./app/models/OTP"));
	  ObjectId= require("mongoose").Types.ObjectId;

class UserController extends App {
	constructor(){
		super();
		/**/
		this.userLogin = this.userLogin.bind(this);
		this.userSignup = this.userSignup.bind(this);
		this.verifyOTP = this.verifyOTP.bind(this);
		this.addUserNotes = this.addUserNotes.bind(this);
		this.otherUserDetails = this.otherUserDetails.bind(this);
		this.userDetails = this.userDetails.bind(this);
		this.updateUserDetails = this.updateUserDetails.bind(this);
		this.updateProfilePicture = this.updateProfilePicture.bind(this);
		
	}

	__if_valid_email(email){
		let re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
		return re.test(email);
	}

	__random(){
	  let string = "12346790";
	  let rand = string.split('');
	  let shuffle = _.shuffle(rand);
	  let num = _.slice(shuffle,0,6);
	  return num.join("");
	}

	/**this method is used to login for user 
    * method : POST
    * endpoint: /api/user-login
    */
	userLogin(req, res){
		let obj = req.body, match = [];
		/*Build conditions for User Login*/
		if(this.__if_valid_email(obj.username)){
			match.push({isEmailActive : true, email : obj.username});
		}else{
			match.push({isEmailActive : true, username : obj.username});
		}
		User.findOne({$and:match},
			{email:1,name:1,auth:1,status:1,password:1,username:1,mobile:1},
			(err, user) => {
				if(err) res.json({type:"error",message:error.oops(),errors:error.pull(err)});
				if(user){
					console.log(User.getPassword(obj.password,user.auth))
					if(!user.status){
						return res.json({type:"error",message:error.oops(),errors:["Your account has been blocked by administator."]});
					}else if(user.password !== User.getPassword(obj.password,user.auth)){
						return res.json({type:"error",message:error.oops(),errors:["Invalid Password."]});
					}else{
						let _user = {_id:user._id, name:user.name, email:user.email,username:user.username ,mobile:user.mobile};
						let token = jwt.sign(_user, env.secret, {expiresIn: '14 days'});
						return res.json({type:"success",message:"Your credentials have been verified.",data:_user,token:token});
					}
				}else{
					return res.json({type:"error",message:error.oops(),errors:["We couldn't found your account."]});
				}
			}
		);		
	}

	/**this method is used to signup the user on usersite
    * method : POST
    * endpoint: /api/user-signup
    */
    userSignup(req, res) {
        let obj = req.body;
        /**if no username */
        if (!obj.username) obj.username = obj.email;
        /* return error if either email or password is not present in the req.body */
        if (!obj.email || !obj.username || !obj.mobile || !obj.ccode) return res.json(this.response({ err: ["Email or Password or Mobile is Missing"], message: "Email or Password or Mobile is Missing" }));
        /**mongo filter to search user by mobile or email id or username */
        let match = { $or: [{ mobile: obj.mobile }, { email: obj.email }, { username: obj.username }] },
            /**fields send to user */
            project = {
                _id: 1, mobile: 1, username: 1, email: 1, name:1, otp:1, isEmailActive:1
            };
        /*check user type */
        User.findOne(match, project, (err, user) => {
        	let body = new Object();
            /**if any error */
            if (err) return res.json(this.response({ err: err, message: error.oops() }));
            /**if user is founded in user collections*/
            if (user){
            	if(user.isEmailActive) return res.json(this.response({ err: ['User Account already exist'], message: "This user already exist !" }));
            	else{
            		body = {
                        name: user.name,email: user.email,username: user.username,appname: env.appname,otp: user.otp,
                    }
                    /**send email to nonverified registered user. */
                    Mailer.Email(body.email, 'registration', 'app/views/', { body: body, subject: `Welcome to ${env.appname} !` });
                    /**if user registered successfully */
                    return res.json(this.response({ data: { userId: user.id }, message: "OTP has been sent on your email to verify your account." }));
            	}
            		
            } 
            /**if user is not founded in user collections  */
            else {
                let user = new User(obj);
                user.save((err, saved_user) => {
                    if (err) return res.json(this.response({ err: err, message: error.oops() }));
                    if (saved_user) {
                        body = {
                            name: saved_user.name,email: saved_user.email, username: saved_user.username,appname: env.appname,otp: saved_user.otp,
                        }
                        /**send email to registered user. */
                        Mailer.Email(body.email, 'registration', 'app/views/', { body: body, subject: `Welcome to ${env.appname} !` });
                        /**if user registered successfully */
                        return res.json(this.response({ data: { userId: saved_user.id }, message: "You've been registered successfully." }));
                    }
                })
            }
        })
    }
    /**this method is used to signup the user on usersite
    * method : POST
    * endpoint: /api/verify-otp
    */
    verifyOTP(req, res){
    	let obj = req.body,
    		match = {otp:obj.otp,email:obj.email},
    		toSet = {isEmailActive:true},
    		project = {
                _id: 1, mobile: 1, username: 1, email: 1
            };
            User.findOneAndUpdate(match, toSet, (err, result) => {
            	if(err) return res.json(this.response({ err: err, message: error.oops() }));
            	if(result){
            	  return res.json(this.response({ data: result._id, message: "Your email has been verified." }));	
            	}else{
            		return res.json(this.response({ err: 'OTP is not matched with this account.', message: error.oops() }));
            	}
            })    		
    }
    /**this method is used add notes for user
    * method : POST
    * endpoint: /api/add-user-notes
    */
    addUserNotes(req,res){
    	let _user = req.user,
    		_obj = req.body;
    		_obj['user_id'] = new ObjectId(_obj['user_id']);
    		_obj['created_at'] = new Date();
    		_obj['updated_at'] = new Date();
    	/*check that if save notes user id should not equal to login userid*/	
    	if(_user._id === _obj.user_id)	return res.json(this.response({ err: 'Your are try to save for you own id', message: error.oops() }));
    	let match = {_id:_user._id,'userNotes.user_id':_obj.user_id},
    		toSet = {$set:{'userNotes.$.note':_obj.note,'userNotes.$.updated_at':new Date()}};
    	/*when user already saved notes against any other user*/
    	User.findOneAndUpdate(match, toSet, (err, result) => {
        	if(err) return res.json(this.response({ err: err, message: error.oops() }));
        	if(result){
        	  return res.json(this.response({ data: result._id, message: "Your note has been updated." }));	
        	}else{
        		/*when user saved notes first time against any other user*/
        		match = {_id:_user._id};
        		toSet = {$push:{userNotes:_obj}};
        		User.update(match,toSet,(err,update)=>{
        			if(err) return res.json(this.response({ err: err, message: error.oops() }));
        			else{
        			   return res.json(this.response({ data: update, message: "Your note has been added." }));		
        			}
        		});
        	}
        })		
    }
    /**this method is used get other user details
    * method : GET
    * endpoint: /api/other-user-details
    */
    otherUserDetails(req, res){
    	let obj = req.query,
    		match = {_id:obj._id},
    		project = {
                _id: 1, mobile: 1, username: 1, email: 1, fullno: 1, ccode: 1
            },
        /*to get other user detail*/
		_otherUser = new Promise((resolve, reject) => {
			User.findOne(match, project, (err, result) => {
				if(err){
				  reject(err)
				}else{
				  resolve(result);	
				}
			});
		}),
		/*to get user add notes*/
		_getUserNotes = new Promise((resolve, reject)=>{
			match = {_id:req.user._id,'userNotes.user_id':ObjectId(obj._id)};
			project ={'userNotes.$':1};
			User.findOne(match, project, (err, result) => {
				if(err){
				  reject(err)
				}else{
				  resolve(result);	
				}
			});	
		})

	    Promise.all([_otherUser,_getUserNotes]).then((result)=>{
	    	return res.json(this.response({ data: result, message: "Success" }));
	    }).catch(function(err) {
		  return res.json(this.response({ err: err, message: error.oops() }));
		});	
    }
    /**this method is used get user details
    * method : GET
    * endpoint: /api/user-details
    */
    userDetails(req, res){
    	let obj = req.user,
    		match = {_id:obj._id},
    		project = {
                _id: 1, mobile: 1, username: 1, name:1, email: 1, fullno: 1, ccode: 1
            };
		User.find(match,project,(err,user)=>{
			if(err) res.json(this.response({ err: err, message: error.oops() }));
			else{
				res.json(this.response({ data: user, message: "Success" }));
			}
		})   	
    }

    /**this method is used to update user details
    * method : PUT
    * endpoint: /api/update-user-details
    */
    updateUserDetails(req, res){
    	let obj = req.user,
    		reqObj = req.body,
    		match = {_id:obj._id},
			UpdateData = {
				name :[reqObj.firstname, reqObj.lastname].join(' '),
			    firstname:reqObj.firstname,
				lastname:reqObj.lastname,
				mobile:reqObj.mobile,
				fullno: [reqObj.ccode, reqObj.mobile].join(''),
				username:reqObj.username,
				ccode:reqObj.ccode,
				updated_at: new Date()
			},
    		toSet = {$set:UpdateData};
    	/*Find user id and update details*/
    	User.findOneAndUpdate(match, toSet, (err, result) => {
    		if(err) res.json(this.response({ err: err, message: error.oops() }));
			else{
				res.json(this.response({ data: result._id, message: "Success" }));
			}
    	})  	
    }
    /**this method is used to update profile picture
    * method : POST
    * endpoint: /api/update-profile-picture
    */
    updateProfilePicture(req, res){
    	let user = req.user,
    	    form = new formidable.IncomingForm(),that = this;
	    form.parse(req, function (err, fields, files) {
	    	let file = files.profileImage,
	    		dir ,
	    	    tempPath = file.path;
	      /*make parent folder*/
		  var makeParent = function(){
		  	return new Promise((resolve, reject) => {
	            dir = `./public/profilePicture`;
	            if(!fs.existsSync(dir)){
	               fs.mkdirSync(dir);
	            }
	            resolve('parent directory created');
			});
		  }
		  /*make child folder*/
		  var makeChild = function(result){
		  	return new Promise((resolve, reject) => {
	            dir = `./public/profilePicture/${user._id}`;
	            if(!fs.existsSync(dir)){
	               fs.mkdirSync(dir);
	            }
	            resolve('child directory created');	
			});
		  }
		  /*move image from temp folder */
		  var moveImage = function(result){
		  	return new Promise((resolve, reject) => {
	          let targetPath = path.resolve(dir + '/' + file.name);
			  mv(tempPath, targetPath, function (err) {
			  	let profilePic = new Object();
			  	profilePic['url'] = `${HostPath.host(req)}profilePicture/${user._id}/${file.name}`;
			  	profilePic['absolute_url'] = targetPath ;
			  	resolve(profilePic);
			  })	
			});
		  }
		  /*update profiel image*/
		  var updateImage = function(result){
		  	return new Promise((resolve, reject) => {
			  	let match = {_id:user._id},
			  	    toSet = {$set:{profilePicture:result}};
			  	User.findOneAndUpdate(match, toSet, (err, result) => {
		    		if(err) reject(err)
					else{
						resolve(result);
					}
		    	}) 
			  });
		  }
		  makeParent().then((result)=>{
		  	return makeChild(result)
		  }).then((result)=>{
		  	return moveImage(result)
		  }).then((result)=>{
		  	return updateImage(result);
		  }).then((result)=>{
		  	//console.log('that--- ',that)
		  	res.json(that.response({ data: result._id, message: "Profile picture has been updated." }));
		  }).catch((err)=>{
		  	res.json(that.response({ err: err, message: error.oops() }));
		  })
	    });
    }

}

module.exports = UserController; 