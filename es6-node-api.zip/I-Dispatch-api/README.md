# node-es6
node server built in Javascript (ES6) classes
