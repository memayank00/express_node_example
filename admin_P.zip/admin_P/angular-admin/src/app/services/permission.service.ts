import { Injectable } from '@angular/core';
import { CookieService } from 'ngx-cookie-service';
import { Sidebar } from '../../app/components/sidebar/sidebar';
import { BehaviorSubject, Observable, of } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class PermissionService {

  permissionSidebar = [];
  displaySidebar = [];
  constructor(private cookieService: CookieService) { }

  private sidebarlist = new BehaviorSubject(this.displaySidebar);
  sendSidebar = this.sidebarlist.asObservable();

  loadSidebar() {
    this.displaySidebar = [];
   this.permissionSidebar = JSON.parse(this.cookieService.get('permissions'));
    this.permissionSidebar.forEach((e1) => Sidebar.forEach((e2) => {

      if (e1 === e2.title) {
        // this.userInfo.next(user);
        this.displaySidebar.push(e2);
        // this.displaySidebar.next(e2);
      }

    }));

    console.log(this.displaySidebar);

    this.displaySidebar.forEach((data) => {
      if (data.path) {
        console.log(data.path);
      } else if (data.submenu) {
        data.submenu.forEach((data2) => {
          console.log(data2.path);
        });
      }

    });
  }

}
