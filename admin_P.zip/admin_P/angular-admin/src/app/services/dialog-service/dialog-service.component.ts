import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dialog-service',
  templateUrl: './dialog-service.component.html',
  styleUrls: ['./dialog-service.component.scss']
})
export class DialogServiceComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
