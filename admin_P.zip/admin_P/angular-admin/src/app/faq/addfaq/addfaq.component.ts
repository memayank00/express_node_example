import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-addfaq',
  templateUrl: './addfaq.component.html',
  styleUrls: ['./addfaq.component.scss']
})
export class AddfaqComponent implements OnInit {

  constructor(
) {}


  ngOnInit() {
  }

}
