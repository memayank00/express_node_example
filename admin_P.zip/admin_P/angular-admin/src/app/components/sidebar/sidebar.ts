export const Sidebar = [
    {
        path: '/dashboard',
        title: 'Dashboard',
        icon: 'dashboard',
    },
    // {
    //      path: '/user',
    //      title: 'User Profile',
    //      icon:'person',
    //      class: ''
    // },
    {
        title: 'Blogs',
        icon: 'content_paste',
        class: '',
        id: 1,
        submenu: [
            {

                title: 'Add Blog',
                path: '/add-blog',
                icon: 'add_circle_outline',
                id: 1.1,
                parentid: 1
            },
            {
                title: 'Blog List',
                path: '/blogs',
                icon: 'list',
                id: 1.2,
                parentid: 1

            }
        ]
     },
    {
         title: 'Pages',
         icon: 'pages',
         class: '',
         id: 2,
         submenu: [
             {

                title: 'Add Page',
                path: '/addpage',
                icon: 'add_circle_outline',
                id: 2.1,
                parentid: 2,

             },
             {
                 title: 'Page List',
                 path: '/pages',
                 icon: 'list',
                 id: 2.2,
                parentid: 2,
             }
         ]
    },
    {
        title: 'User Admin',
        icon: 'library_books',
        class: '',
        submenu: [
            {
               title: 'Add User Admin',
               path: '/add-user-admin',
               icon: 'add_circle_outline'
            },
            {
                title: 'User Admin List',
                path: '/add-blog',
                icon: 'list'
            }
        ]
   },
   {

        title: 'Faq',
        icon: 'question_answer',
        class: '',
        submenu: [
            {
                title: 'Add Faq',
                path: '/faq',
                icon: 'add_circle_outline'
            },
            {
                title: 'Faq List',
                path: '/addfaq',
                icon: 'list'
            }
        ]
   },
   {

        title: 'Admin Management',
        icon: 'question_answer',
        class: '',
        submenu: [
            {
                title: 'Add Admin Role',
                path: '/add-admin-role',
                icon: 'add_circle_outline'
            },
            {
                title: 'Admin Role List',
                path: '/admin-role-list',
                icon: 'list'
            }
        ]
   },

   {
        path: '/pages',
        title: 'Settings',
        icon: 'settings',
        class: ''
    },

    // {
    //     path: '/addpage',
    //     title: 'Logout',
    //     icon:'exit_to_app',
    //     class: ''
    // }
];
