import {Component, OnInit} from '@angular/core';
import { environment } from '../../../environments/environment';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-blogs',
  templateUrl: './blogs.component.html',
  styleUrls: ['./blogs.component.scss']

})


export class BlogsComponent implements OnInit {
  displayedColumns: string[] = ['No', 'title', 'Action'];
  dataSource;
  tableData = [];
  private list = `${environment.apiUrl}postlist?type=page&page=1&limit=5`;
  constructor(private httpClient: HttpClient ) { }


  user = {
    title: 'Contact'
  };

  pagelist() {


    this.httpClient.get<any>(this.list).subscribe((response) => {

      this.tableData = response.data.data;

      this.dataSource = response.data.data;

    }, (error) => {
      console.log(error);
    });

}


checkId(id) {
  console.log(id);
}




  ngOnInit() {

    // this.dataSource.paginator = this.paginator;
    this.pagelist();
  }

}

