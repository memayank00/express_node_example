import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-addblogs',
  templateUrl: './addblogs.component.html',
  styleUrls: ['./addblogs.component.scss']
})
export class AddblogsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
