import { Routes, RouterModule } from '@angular/router';
import { DashboardComponent } from '../dashboard/dashboard.component';
import { BlogsComponent } from '../blogs/blogs/blogs.component';
import { AddblogsComponent  } from '../blogs/addblogs/addblogs.component';
import { ViewpageComponent } from '../pages/viewpage/viewpage.component';
import { EditpageComponent } from '../pages/editpage/editpage.component';
import { AddpageComponent } from '../pages/addpage/addpage.component';
import { AuthguardGuard } from '../authguard.guard';
import { FaqComponent } from '../faq/faq/faq.component';
import { AddfaqComponent } from '../faq/addfaq/addfaq.component';
import { ProfileComponent } from '../profile/profile.component';
import { AddadminComponent } from '../admin/addadmin/addadmin.component';
import { AddroleComponent } from '../adminmanagement/addrole/addrole.component';
import { AdminrolelistComponent } from '../adminmanagement/adminrolelist/adminrolelist.component';
import { EditroleComponent } from '../adminmanagement/editrole/editrole.component';


export const components = [DashboardComponent,
    BlogsComponent, AddblogsComponent, ViewpageComponent,
    AddpageComponent, EditpageComponent, FaqComponent, AddfaqComponent, ProfileComponent,
    AddadminComponent, AddroleComponent, AdminrolelistComponent, EditroleComponent];
export const entryComponents = [AddadminComponent];
export const routes: Routes =  [
     {path: 'dashboard', component: DashboardComponent, canActivate: [AuthguardGuard]},
     {path: 'blogs', component: BlogsComponent, canActivate: [AuthguardGuard]},
     {path: 'add-blog', component: AddblogsComponent, canActivate: [AuthguardGuard]},
     {path: 'pages', component: ViewpageComponent, canActivate: [AuthguardGuard]},
     {path: 'addpage', component: AddpageComponent, canActivate: [AuthguardGuard]},
     {path: 'editpage/:post_id', component: EditpageComponent, canActivate: [AuthguardGuard]},
     {path: 'faq', component: FaqComponent, canActivate: [AuthguardGuard]},
     {path: 'addfaq', component: AddfaqComponent, canActivate: [AuthguardGuard]},
     {path: 'profile', component: ProfileComponent, canActivate: [AuthguardGuard]},
     {path: 'add-user-admin', component: AddadminComponent, canActivate: [AuthguardGuard]},
     {path: 'add-admin-role', component: AddroleComponent, canActivate: [AuthguardGuard]},
     {path: 'admin-role-list', component: AdminrolelistComponent, canActivate: [AuthguardGuard]},
     {path: 'edit-role/:post_id', component: EditroleComponent, canActivate: [AuthguardGuard]}

    ];
