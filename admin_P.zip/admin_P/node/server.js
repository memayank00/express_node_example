'use strict';

require('dotenv').config({silent: true});
const express 		= require('express'),
	helmet 			= require('helmet'),
	fs 				= require('fs'),
	path 			= require('path'),
	bodyParser 		= require('body-parser'),
	cors 			= require('cors'),
	database		= require(path.resolve('./app/config/libs/mongoose')),
	router			= express.Router(),
	routes			= require('./app/config/route'),
	http 			= require('http'),
	Admin			=require(path.resolve('./app/controllers/backend/index')),
    env				= require(path.resolve(`./app/config/env/${process.env.NODE_ENV}`));

class Server {
	constructor(){
		
        /*defining PORT for application*/
		this.port   = env.server.PORT || 4000;
		
		/*init express app*/
		this.app    = express();
		
		/*init a sever*/
		this.server = http.createServer(this.app);
		
		/*init helmets for securing http headers*/
		this.helmet = helmet();
		
		/*init cors for multiple origin requests*/
		this.cors   = cors();

		this.router=router;

		
		this.routes;

	}

	secureHeaders(){
		/*protect http headers of server through Helmet*/
		this.app.use(this.helmet);
	}

	initRoutes(){

		this.routes	=	new routes(this.app, this.router).init();
	}

	appConfig(){
		/*allow application to read and send data in body*/
		this.app.use(bodyParser.json({limit: '50mb'}));
		this.app.use(bodyParser.urlencoded({limit: '50mb', extended: true}));
	}

	enablingCors(){
		/*enable application CORS*/
		this.app.use(this.cors);
	}
	setAPIRoutes(){
		/*routing /&admin apis*/
		this.app.use('/api', this.routes);
		this.app.use('/admin_api', this.routes);
	}
	setStaticPaths(){
		this.app.use(express.static(__dirname + '/uploads'));	
	}

	allowToServe(){
		/*rendering file on routes*/
		this.app.get(/^((?!\/(api)).)*$/, (req, res) => {
		     res.sendFile(path.resolve('./public/index.html'));
		});
	}


	connectDatabase(){
		new database().dbConnect();
	}


	init(){
		this.secureHeaders();
		this.appConfig();
		this.enablingCors();
		this.connectDatabase();
		this.initRoutes();
		this.setAPIRoutes();
		this.setStaticPaths();
		this.allowToServe();

		this.server.listen(this.port, () => {
			//this.Admin.checkAdmin();
			 this.Admin=new Admin();

			 this.Admin.checkAdmin();
			console.log('listening on', this.server.address().port);
		});
	}
}

let application = new Server();

application.init();