'use strict';

const path          = require('path'),
      Admin         = require(path.resolve('./app/models/admin')),
      crypto        = require('crypto'),
      env           =require(path.resolve(`./app/config/env/${process.env.NODE_ENV}`)),
      decode        =require(path.resolve('./app/config/libs/jwt')),
      secret        = new Buffer(env.secret).toString('base64'),
      formidable    =require('formidable'),
      jwt           = require('jsonwebtoken');

 class AdminController{

        constructor(){


            this.adminLogin =   this.adminLogin.bind(this);
            this.updatePassword= this.updatePassword.bind(this);
            this.profileImage=this.profileImage.bind(this);
            this.getUserProfile=this.getUserProfile.bind(this);
            this.updateUserProfile=this.updateUserProfile.bind(this);
            this.registerUserAdmin = this.registerUserAdmin.bind(this);
        }
    
        Login(req, res){

            let obj=req.body
            /*encrypt the password */
            if(obj.password){
                obj.password=crypto.createHmac('sha512', env.secret).update(obj.password).digest('base64');
            }
            
            Admin.findOne({email:obj.email},(err, result)=>{
                if(err){
                    res.json({success:false, message:err})
                }
                else{
                    if(result){
                        if(result.password===obj.password){

                           let user={
                                _id:result._id,
                                email: result.email,
                                firstname:result.firstname,
                                lastname:result.lastname,
                                type:result.type
                            }
                            /*create token */
                            let token=jwt.sign(user, secret,{ expiresIn: 60 * 60 })
                            
                            res.json({success:true, message:"success", Token:token});
                        }else{
                            res.json({message:"Invalid Email or Password"})
                        }
                    }else{
                        res.json({message:"Email id is not Valid"});
                    }
                }
            })

        } 

        adminLogin(req,res){

            let obj=req.body

            if(obj.password){
                obj.password=crypto.createHmac('sha512', env.secret).update(obj.password).digest('base64');
            }

            Admin.aggregate([{$match:{email:obj.email, password: obj.password}}
                ,{
                  
                $lookup:{

                    from: "adminroles",
                    localField: "role_id",
                    foreignField:"_id",
                    as:"data"

                }
            },
            {
                $unwind:"$data"
            },
            {
                $project:{

                "data.permissions":1,
                role:1,
                email:1

            }}
        ],(error, result)=>{
                if(error){
                    res.json({success:false, error:error})
                }else{
                    if(result){

                        let user={
                            _id:result[0]._id,
                            email: result[0].email,

                        }
                        let token=jwt.sign(user, secret,{ expiresIn: 60 * 60 })

                        res.json({success:true, result:result[0].data.permissions, Token:token})
                    }else{
                        res.json({success:fale})
                    }
                }
            })



        }


        updatePassword(req, res){
            decode.run(req,secret,(data)=>{
                let obj=req.body
                if(obj.password){
                    obj.password=crypto.createHmac('sha512', env.secret).update(obj.password).digest('base64');
                    obj.newpassword=crypto.createHmac('sha512', env.secret).update(obj.newpassword).digest('base64');

                }
                Admin.findOneAndUpdate(
                    {_id:data._id, password:obj.password},
                    {password:obj.newpassword},
                    {new:true},(err, result)=>{
                        if(err){
                            res.json({success:false, message:err})
                        }else{
                            if(result){
                                res.json({success:true, message:"Password Successfully Updated"})
                            }else{
                                res.json({success:false, message:"false"})
                            }
                        }

                    }
                )

            })        

        }



        getUserProfile(req,res){

            decode.run(req,secret,(data)=>{

                Admin.findOne({_id:data._id},
                    {firstname:1, 
                     lastname:1,
                     email:1,
                     username:1,
                     mobile:1,
                     address:1
                    },(err, result)=>{
                        if(err){
                            res.json({success:false, message:err})
                        }else{
                            if(result){
                                res.json({success:true, data:result})
                            }else{
                                res.json({success:false})
                            }
                        }
                    }
                )
            })
        }

        updateUserProfile(req, res){

            decode.run(req, res, (data)=>{

                    let obj=req.body;
                Admin.findOneAndUpdate({_id:data._id},
                    {

                        firstname:obj.firstname,
                        lastname:obj.lastname,
                        mobile:obj.mobile,
                        address: obj.address
                    },{
                        new:  true
                    },(error, result)=>{

                        if(error){
                            res.json({success:false, message:error})
                        }else{
                            if(result){
                                res.json({success:true, message:"Profile is successfully updated"})
                            }else{
                                res.json({success:false, message:"error"})
                            }
                        }
                    }
                )
            })

        }


        registerUserAdmin(req,res){
            decode.run(req, secret, (data)=>{

                let obj=req.body;

                var admin = new Admin(obj);

                admin.save((error,result)=>{
                    if(error) {
                        res.json({success:false});
                    }else{
                        if(result){
                            res.json({success:true, Message: "Admin User Successfully Created"});
                        }else{
                            res.json({success:false});
                        }
                    }
                })
                
            })
        }

        profileImage(req, res){
            

            res.json({message:"test"});

            // decode.run(req, secret,(data)=>{

            //     var form=new formidable.IncomingForm();
            //     form.parse(req);
            //     form.on('fileBegin', function (name, file){
            //         // file.path = __dirname + '/uploads/';
            //         return false;
            //     });
            
            //     form.on('file', function (name, file){
            //         console.log('Uploaded ' + file.name);
            //     });
            // })
        }
}

   module.exports = AdminController;