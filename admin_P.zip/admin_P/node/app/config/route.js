'use strict';

const path               =   require('path'),
      fs                 =   require('fs'),
      expressJWT         =   require('express-jwt'),
      env                =   require(path.resolve(`./app/config/env/${process.env.NODE_ENV}`)),
      api_path           =   env.API.site,
      admin_api_path     =   env.API.admin;

class AppRouter {

    constructor(app, router){
        this.call={
            backend:{}
        };

        this.backend    ={};

        this.api_path=api_path;
        this.admin_api=admin_api_path; 

        this.app=app;
        this.router=router;
    }
    
    loadAppClasses(){

        fs.readdirSync(path.resolve('./app/controllers/backend')).forEach(file=>{
            let name =file.substr(0, file.indexOf('.'));

            this.backend[name]=require(path.resolve(`./app/controllers/backend/${name}`));
                console.log(name);
            this.call['backend'][name] =   new this.backend[name]();
        });
    }

    unlessRoutes(){
        this.router.use(expressJWT({

            secret:new Buffer(env.secret).toString('base64'),

        }).unless({
            path:[
                //  this.admin_api_path+'';

                this.admin_api+'/admin-login',
                this.admin_api+'/profileimage',
                // this.admin_api+'/update_password',
            ]
        }));
    }

    loadAppRoutes(){

        this.router.post('/admin-login', this.call['backend']['AdminController'].adminLogin);
        this.router.post('/update_password', this.call['backend']['AdminController'].updatePassword);
        this.router.get('/profileimage', this.call['backend']['AdminController'].profileImage)
        this.router.get('/get_profile', this.call['backend']['AdminController'].getUserProfile);
        this.router.post('/updateUserProfile',this.call['backend']['AdminController'].updateUserProfile);
        this.router.post('/registerUserAdmin', this.call['backend']['AdminController'].registerUserAdmin);


        this.router.post('/addPost', this.call['backend']['PostController'].createPost);
        this.router.post('/addPostWithImage', this.call['backend']['PostController'].addPostWithImage);
        this.router.get('/postlist', this.call['backend']['PostController'].postList);
        this.router.post('/removeSinglePost', this.call['backend']['PostController'].removeSinglePost)
        this.router.post('/getSinglePost', this.call['backend']['PostController'].getSinglePost);
        this.router.post('/removeMultiplePost', this.call['backend']['PostController'].removeMultiplePost);
        this.router.post('/editPost', this.call['backend']['PostController'].editPost);
        this.router.post('/editPostWithImage', this.call['backend']['PostController'].editPostWithImage);
        this.router.post('/changeStatus', this.call['backend']['PostController'].changeStatus);


        this.router.post('/addRole', this.call['backend']['AdminRoleController'].addRole);
        this.router.get('/adminRoleList', this.call['backend']['AdminRoleController'].adminRoleList);
        this.router.post('/deleteRole', this.call['backend']['AdminRoleController'].deleteRole);
        this.router.post('/deleteSingleRole', this.call['backend']['AdminRoleController'].deleteSingleRole);
        this.router.post('/getSingleRole',this.call['backend']['AdminRoleController'].getSingleRole);
        this.router.post('/editRole', this.call['backend']['AdminRoleController'].editRole);
        this.router.get('/rolelist', this.call['backend']['AdminRoleController'].rolelist);

    }

    init(){
        this.loadAppClasses();
        this.unlessRoutes();
        this.loadAppRoutes();
        return this.router;
    }
}
module.exports=AppRouter;