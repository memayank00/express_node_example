'use strice'; 

const  mongoose         =require('mongoose'),
       Schema           =mongoose.Schema;
       
var roleSchema= new Schema({

    role:         String,
    status:       String,
    permissions:[],
    trash      :{
                    type:Boolean,
                    default:false

                    }
    

},{
    timestamps:{
        createdAt:'create_at',
        updatedAt:'updated_at'
    }
});

module.exports=mongoose.model('adminrole',roleSchema);