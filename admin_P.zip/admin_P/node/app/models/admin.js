'use strict';

const mongoose          = require('mongoose'),
      path              = require('path'),
      config            = require(path.resolve(`./app/config/env/${process.env.NODE_ENV}`)),
      crypto            = require('crypto'),
      uniquevaidator    = require('mongoose-unique-validator'),
      Schema            =mongoose.Schema;

var adminSchema= new Schema({
    
    firstname: String,
    lastname:  String,
    mobile: String,
    password:String,
    username:String,
    email:{
        type: String,
        lowercase:true,
        trim:true,
        required:'email is required',
        unique:'email should unique'
    },
    type:Number,
    image:String,
    OTP:String,
    role:String,
    role_id:String,
    address: String,
    status:{
        type:Boolean,
        defalut:true
    } 
},{
    timestamps:{
        createdAt:'create_at',
        updatedAT:'updated_at'
    }
});

adminSchema.pre('save', function(next){
    this.password=crypto.createHmac('sha512', config.secret).update(this.password).digest('base64');
    next();
} )    

adminSchema.plugin(uniquevaidator);

module.exports=mongoose.model('admin', adminSchema);